/**
 * Name: Thomass Muir, ICS3U
 * File: translate.java
 * Description: Method header for method named translate that takes an integer
 *              parameter and returns a double.
 */
public class Translate {


    public static void main (String[] args){

        translate(7);
    }

    public static double translate (int arg){
       return 0.0;
    }
}
