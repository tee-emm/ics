/**
 * Name: Thomass Muir, ICS3U
 * File: printAnswer.java
 * Description: Method header for a method named printAnswer that takes three doubles as parameters
 *              and does not return anything.
 */
public class PrintAnswer {

    public static void main(String[] args){

    }

    public static void printAnswer (double arg1, double arg2, double arg3){

    }

}
