/**
 * Name: Thomass Muir, ICS3U
 * File: find.java
 * Description: Method header for method named find that takes a String and a double as
 *              parameters and returns an integer.
 */
public class Find {

    public static void main (String[] args){

    }

    public static int find (String arg1, double arg2){

        return 0;
    }
}
